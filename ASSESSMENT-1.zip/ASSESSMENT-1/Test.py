# ANKITA MOHANTY
# SUPERSET ID: 6361211
# EMAIL ID: 2205446@KIIT.AC.IN


from selenium.webdriver import Chrome, ChromeOptions #web driver
from selenium.webdriver.common.by import By #locators
from selenium.webdriver.common.keys import Keys #keyboard actions
from selenium.webdriver.support.select import Select #dropdowns
from selenium.webdriver.common.action_chains import ActionChains #mouse actions
from time import sleep

o = ChromeOptions()
o.add_experimental_option("detach",True)
driver = Chrome(options=o)
driver.maximize_window()

# 1. navigate to amazon and print all category names
# driver.get("https://www.amazon.in/")
# sleep(9)
# a=driver.find_elements("xpath","//li[@class='nav-li']")
# sleep(2)
# for i in a:
#     print(i.text)

# 2. print top 10 movies names from imdb top 250
# driver.get("https://www.imdb.com/chart/top/")
# sleep(5)
# movies = driver.find_elements(By.XPATH, "//h3[@class='ipc-title__text']")
# for movie in movies[:10]:
#     print(movie.text)

# 3. count all images on amazon
# driver.get("https://www.amazon.in/")
# sleep(4)
# a=driver.find_elements("xpath","//img")
# c=0
# for i in a:
#     c+=1
# print("total images :",c)

# 4. open demoqa and Target first dropdown in that page and select first option
driver.get("https://demoqa.com/select-menu")
sleep(7)
a=driver.find_element("id","oldSelectMenu")
o=Select(a)
o.select_by_index(0)

# 5. print all links in amazon page
# driver.get("https://www.amazon.in/")
# sleep(4)
# a=driver.find_elements("xpath","//link")
# for i in a:
#     print(i.get_attribute("href"))

# 6. print auto-suggestions of any site
# driver.get("https://www.myntra.com/shop/men/")
# sleep(4)
# driver.find_element("xpath","//input[@class='desktop-searchBar']").send_keys("Crochet Dresses")
# sleep(4)
# a=driver.find_elements("xpath","//li[@class='desktop-suggestion null']")
# for i in a:
#     print(i.text)

# 7. From the “Accounts & Lists” section on the Amazon homepage, select the “Your Wish List” option.
# driver.get("https://www.amazon.in/")
# sleep(2)
# a = driver.find_element("id", "nav-link-accountList")
# o=ActionChains(driver)
# o.move_to_element(a).perform()
# sleep(2)
# driver.find_element(By.LINK_TEXT, "Your Wish List").click()

# 8. Access the content displayed inside the embedded page of w3schools and print the heading text visible inside it.
# driver.get("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_iframe")
# driver.switch_to.frame("iframeResult")
# driver.switch_to.frame(0)
# a = driver.find_element(By.TAG_NAME, "h1").text
# print(a)

# 9. Search Laptop and print all product titles.
# driver.get("https://www.amazon.in/")
# sleep(4)
# search = driver.find_element(By.ID, "twotabsearchtextbox")
# search.send_keys("Laptop")
# search.send_keys(Keys.ENTER)
# sleep(5)
# products = driver.find_elements(By.XPATH, "//h2[@class='a-size-medium a-spacing-none a-color-base a-text-normal']//span")
# for p in products:
#     print(p.text)


